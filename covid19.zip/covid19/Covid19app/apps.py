from django.apps import AppConfig


class Covid19AppConfig(AppConfig):
    name = 'Covid19app'
